# Al-Athan Iraq (Android TV)

A from-scratch native Android TV app (Kotlin) for Iraqi prayer times. This is
original code with its own branding — it is **not** derived from or a
repackaging of any existing prayer-times app (e.g. Mawaqit). That's
intentional: modifying and redistributing someone else's app under a new
name/logo would be a copyright violation, so this project builds the same
kind of functionality independently.

## What's included

- **Splash screen**: full-screen branded startup image
  (`res/drawable-nodpi/splash_screen.png`) shown for ~2 seconds via
  `SplashActivity`, then hands off to the home screen.
- **Home screen** (`activity_main.xml`, ConstraintLayout):
  - Hamburger menu button, top-left corner. Opens a menu
    (`MenuActivity`) with, in order: **Change Location**, **Iqama**, **About**.
  - Mosque name + district/governorate name, top-center, mosque name first with the location to
    its right. Mosque name is stored in `Prefs` (default "Central Mosque" —
    set `Prefs.setMosqueName(...)` wherever makes sense for your install,
    e.g. a future settings screen).
  - Gregorian + Hijri date, top-right corner.
  - Live countdown to the next prayer, centered.
  - 5 prayer-time cards (Fajr, Dhuhr, Asr, Maghrib, Isha), redesigned to
    match the supplied reference image: teal card, mint border, large
    rounded corners. Each card shows the prayer name, the adhan time, and
    the iqama offset (e.g. "+8") — all the same bold white text, name and
    time at matching size.
  - App branding lockup (logo + "Al-Athan Iraq" wordmark), bottom-right
    corner.
- **Governorate → District picker** (`DistrictPickerActivity`): two-step
  location selection covering all 18 Iraqi governorates and their districts
  (qadha) — e.g. Baghdad → Karkh/Rusafa/Adhamiyah/Kadhimiya/etc., Nineveh →
  Mosul/Tel Afar/Sinjar/etc. Pick a governorate, then a district within it;
  the D-pad/system back button steps back one level before exiting the
  screen. See `IraqRegions.kt` to add, rename, or adjust coordinates for any
  governorate or district. The home screen shows the selected district and
  governorate together (e.g. "Karkh, Baghdad").
- **Iqama settings** (`IqamaSettingsActivity`): a +/- stepper per prayer to
  set how many minutes after adhan the iqama is called (0–60 min, saved
  immediately). Defaults: Fajr 20, Dhuhr 15, Asr 15, Maghrib 8, Isha 15 —
  see `Prefs.kt` (`DEFAULT_IQAMA_OFFSETS`) to change the starting values.
  Note: the app currently displays this as an *offset* (e.g. "+8"), matching
  the reference design, rather than computing and showing an absolute iqama
  clock time — that'd be a natural next step if you want it.
- **About screen** (`AboutActivity`): logo, app name, version (pulled from
  `versionName` via `BuildConfig`), and a short description.
- **Prayer time source**: [Aladhan API](https://aladhan.com/prayer-times-api)
  (free, no key required), calculation method defaults to the Egyptian
  General Authority of Survey (method=2), commonly used across Iraq. You can
  change this in `AladhanApi.kt`.
- **Hijri date**: comes from the same Aladhan API response.
- **Athan (call to prayer) audio**: `AthanScheduler` + `AthanAlarmReceiver`
  schedule an `AlarmManager` alarm for each remaining prayer today and play
  `res/raw/athan.mp3` when it fires.
- **Original branding**: app name "Al-Athan Iraq", using your two supplied
  images as the actual app assets:
  - `1787396927141__1_.png` → launcher icon (all mipmap densities) and the
    home-screen logo (`res/drawable-nodpi/logo_al_athan.png`), plus a
    generated Android TV banner (`tv_banner_final.png`).
  - `Al-Athan_Iraq_Start_up.png` → the splash screen
    (`res/drawable-nodpi/splash_screen.png`).
  No Mawaqit logo or assets anywhere in this project.

## ⚠️ Before you build: add a real athan audio file

`app/src/main/res/raw/athan.mp3` is currently a **placeholder text file**,
not real audio — I can't source or embed a specific athan recording for you
without knowing its licensing. Before building:

1. Get an athan recording you have the rights to use (many reciters release
   recordings under permissive licenses — check the terms before using one).
2. Replace `app/src/main/res/raw/athan.mp3` with that file (keep the same
   filename).

Without this, the app runs fine but plays no sound at prayer time (the
receiver fails silently rather than crashing).

## Building the APK

This project includes the Gradle wrapper (`gradlew`, `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.jar`), so no separate Gradle install is
needed.

1. Clone the repo (or open the folder you just downloaded from GitHub) in
   [Android Studio](https://developer.android.com/studio) (Hedgehog or
   newer) — it will sync automatically.
2. Replace `res/raw/athan.mp3` as described above.
3. Build from Android Studio (`Build > Generate Signed Bundle / APK`), or
   from a terminal:
   ```bash
   ./gradlew assembleDebug        # macOS/Linux
   gradlew.bat assembleDebug      # Windows
   ```
4. Sideload the resulting APK onto your Android TV via
   `adb install app/build/outputs/apk/debug/app-debug.apk`, or copy it to a
   USB drive and install with a file manager app.

## Pushing to GitHub

This zip is structured as a ready-to-go repo root (`.gitignore`, `LICENSE`,
Gradle wrapper included — build output and local config are already
git-ignored). To publish it:

```bash
cd al-athan-iraq
git init
git add .
git commit -m "Initial commit: Al-Athan Iraq Android TV app"
git branch -M main
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

Or, on GitHub's web UI: create a new empty repository (no README/license/
gitignore, since this zip already has them), then use "uploading an existing
file" and drag in the extracted folder contents — though the `git` route
above is recommended so the Gradle wrapper's executable bit on `gradlew` is
preserved.

## Project structure

```
app/src/main/java/com/alathaniraq/tv/
  data/     Governorate/District list (IraqRegions.kt), Aladhan API client + models, repository
  ui/       MainActivity (home screen), DistrictPickerActivity, MenuActivity,
            IqamaSettingsActivity, AboutActivity, SplashActivity
  util/     Prefs, AthanScheduler, AthanAlarmReceiver, BootReceiver, date formatting
app/src/main/res/
  layout/   activity_main.xml, activity_district_picker.xml, activity_menu.xml,
            activity_iqama_settings.xml, activity_about.xml, item_prayer_card.xml,
            item_region.xml, item_iqama_row.xml
  drawable/ Launcher icon, TV banner, card + button styles
  values/   strings.xml, colors.xml (mosque-green + teal + gold theme), themes.xml
```

## Known limitations / next steps

- Alarms are (re)scheduled only for the *remaining* prayers each time the
  app is opened (or on boot). For a fully "set and forget" install, swap
  `BootReceiver`'s activity launch for a daily `WorkManager` job that
  fetches tomorrow's timings just after midnight and reschedules.
- Location list covers the 18 governorates with a representative set of
  districts per governorate (not exhaustive down to every sub-district).
  Add more `District(...)` entries per `Governorate(...)` in
  `IraqRegions.kt` as needed, or wire up a location-based lookup.
- No offline caching yet — the app fetches from Aladhan each time it opens.
- Calculation method defaults to method=2; if you want the method used by a
  specific Iraqi religious authority, check Aladhan's docs for the closest
  match or supply custom angles.
