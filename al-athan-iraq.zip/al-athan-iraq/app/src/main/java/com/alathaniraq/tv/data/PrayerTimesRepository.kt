package com.alathaniraq.tv.data

class PrayerTimesRepository(private val api: AladhanApi = AladhanApi.create()) {

    suspend fun fetchToday(district: District): Result<AladhanData> {
        return try {
            val response = api.getTimings(
                latitude = district.latitude,
                longitude = district.longitude,
                timestamp = System.currentTimeMillis() / 1000
            )
            val data = response.data
            if (data != null) Result.success(data) else Result.failure(IllegalStateException("Empty response"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
