package com.alathaniraq.tv.util

import android.content.Context

object Prefs {
    private const val FILE = "al_athan_iraq_prefs"
    private const val KEY_DISTRICT = "selected_district_id"
    private const val KEY_MOSQUE_NAME = "mosque_name"

    fun getDistrictId(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_DISTRICT, null) ?: com.alathaniraq.tv.data.IraqRegions.defaultDistrict().id
    }

    fun setDistrictId(context: Context, districtId: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_DISTRICT, districtId).apply()
    }

    /** Display name for the mosque shown at the top of the home screen. Editable per-install. */
    fun getMosqueName(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_MOSQUE_NAME, null) ?: context.getString(com.alathaniraq.tv.R.string.default_mosque_name)
    }

    fun setMosqueName(context: Context, name: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_MOSQUE_NAME, name).apply()
    }

    // --- Iqama offsets (minutes after adhan), editable via the Iqama settings screen ---
    // Defaults follow a common local convention; Maghrib defaults to 8 to match the
    // reference design. Adjust freely — these are just sensible starting points.
    private val DEFAULT_IQAMA_OFFSETS = mapOf(
        "fajr" to 20,
        "dhuhr" to 15,
        "asr" to 15,
        "maghrib" to 8,
        "isha" to 15
    )

    private fun iqamaKey(prayerKey: String) = "iqama_offset_$prayerKey"

    /** [prayerKey] is one of "fajr", "dhuhr", "asr", "maghrib", "isha". */
    fun getIqamaOffset(context: Context, prayerKey: String): Int {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val default = DEFAULT_IQAMA_OFFSETS[prayerKey] ?: 15
        return sp.getInt(iqamaKey(prayerKey), default)
    }

    fun setIqamaOffset(context: Context, prayerKey: String, minutes: Int) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putInt(iqamaKey(prayerKey), minutes).apply()
    }
}
