package com.alathaniraq.tv.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.alathaniraq.tv.BuildConfig
import com.alathaniraq.tv.R
import com.alathaniraq.tv.databinding.ActivityAboutBinding

class AboutActivity : ComponentActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.versionText.text = getString(R.string.version_format, BuildConfig.VERSION_NAME)
        binding.closeButton.setOnClickListener { finish() }
        binding.closeButton.requestFocus()
    }
}
