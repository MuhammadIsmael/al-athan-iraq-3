package com.alathaniraq.tv.data

import com.google.gson.annotations.SerializedName

data class AladhanResponse(
    val data: AladhanData?
)

data class AladhanData(
    val timings: Timings,
    val date: DateInfo
)

data class Timings(
    @SerializedName("Fajr") val fajr: String,
    @SerializedName("Sunrise") val sunrise: String,
    @SerializedName("Dhuhr") val dhuhr: String,
    @SerializedName("Asr") val asr: String,
    @SerializedName("Maghrib") val maghrib: String,
    @SerializedName("Isha") val isha: String
)

data class DateInfo(
    val readable: String,
    val hijri: HijriDate
)

data class HijriDate(
    val day: String,
    val month: HijriMonth,
    val year: String
)

data class HijriMonth(
    val en: String,
    val ar: String
)
