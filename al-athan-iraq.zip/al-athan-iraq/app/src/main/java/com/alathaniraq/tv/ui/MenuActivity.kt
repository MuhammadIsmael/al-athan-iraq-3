package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.alathaniraq.tv.databinding.ActivityMenuBinding

/**
 * The hamburger-button menu. Order matters here (matches the requested layout):
 * 1. Change City
 * 2. Iqama (per-prayer iqama offset adjustment)
 * 3. About
 *
 * Returns RESULT_OK to MainActivity if anything changed that requires a refresh
 * (city or iqama offsets); About is view-only and doesn't trigger a refresh.
 */
class MenuActivity : ComponentActivity() {

    private lateinit var binding: ActivityMenuBinding
    private var didChange = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuChangeCity.setOnClickListener {
            startActivityForResult(Intent(this, DistrictPickerActivity::class.java), REQUEST_CITY)
        }
        binding.menuIqama.setOnClickListener {
            startActivityForResult(Intent(this, IqamaSettingsActivity::class.java), REQUEST_IQAMA)
        }
        binding.menuAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        binding.menuChangeCity.requestFocus()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK &&
            (requestCode == REQUEST_CITY || requestCode == REQUEST_IQAMA)
        ) {
            didChange = true
        }
    }

    private fun finishWithResult() {
        setResult(if (didChange) Activity.RESULT_OK else Activity.RESULT_CANCELED)
    }

    override fun finish() {
        finishWithResult()
        super.finish()
    }

    companion object {
        private const val REQUEST_CITY = 100
        private const val REQUEST_IQAMA = 101
    }
}
