package com.alathaniraq.tv.util

import com.alathaniraq.tv.data.HijriDate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateFormatting {

    fun gregorianToday(): String {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH)
        return sdf.format(Date())
    }

    /** Formats the Hijri date object returned by the Aladhan API, e.g. "12 Rabi' al-awwal 1448 AH". */
    fun formatHijri(hijri: HijriDate): String {
        return "${hijri.day} ${hijri.month.en} ${hijri.year} AH"
    }
}
