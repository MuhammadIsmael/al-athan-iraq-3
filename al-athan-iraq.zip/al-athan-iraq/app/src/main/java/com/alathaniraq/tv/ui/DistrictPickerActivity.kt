package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.alathaniraq.tv.R
import com.alathaniraq.tv.data.Governorate
import com.alathaniraq.tv.data.IraqRegions
import com.alathaniraq.tv.databinding.ActivityDistrictPickerBinding
import com.alathaniraq.tv.databinding.ItemRegionBinding
import com.alathaniraq.tv.util.Prefs

/**
 * Two-step location picker: choose a Governorate, then a District within it.
 * The system/D-pad back button steps back from the district list to the
 * governorate list before exiting the screen entirely.
 */
class DistrictPickerActivity : Activity() {

    private lateinit var binding: ActivityDistrictPickerBinding
    private var selectedGovernorate: Governorate? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDistrictPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        showGovernorates()
    }

    override fun onBackPressed() {
        if (selectedGovernorate != null) {
            showGovernorates()
        } else {
            super.onBackPressed()
        }
    }

    private fun showGovernorates() {
        selectedGovernorate = null
        binding.pickerTitle.text = getString(R.string.select_governorate)
        binding.pickerHint.text = getString(R.string.select_governorate_hint)
        binding.regionGrid.adapter = RegionAdapter(IraqRegions.ALL.map { it.displayName }) { index ->
            showDistricts(IraqRegions.ALL[index])
        }
    }

    private fun showDistricts(governorate: Governorate) {
        selectedGovernorate = governorate
        binding.pickerTitle.text = governorate.displayName
        binding.pickerHint.text = getString(R.string.select_district_hint)
        binding.regionGrid.adapter = RegionAdapter(governorate.districts.map { it.displayName }) { index ->
            val district = governorate.districts[index]
            Prefs.setDistrictId(this, district.id)
            setResult(RESULT_OK)
            finish()
        }
    }

    private class RegionAdapter(
        private val labels: List<String>,
        private val onClick: (Int) -> Unit
    ) : RecyclerView.Adapter<RegionAdapter.VH>() {

        inner class VH(val binding: ItemRegionBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val inflater = LayoutInflater.from(parent.context)
            val binding = ItemRegionBinding.inflate(inflater, parent, false)
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.binding.regionLabel.text = labels[position]
            holder.binding.root.setOnClickListener { onClick(position) }
        }

        override fun getItemCount(): Int = labels.size
    }
}
