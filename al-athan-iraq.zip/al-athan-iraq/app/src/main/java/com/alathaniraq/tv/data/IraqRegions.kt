package com.alathaniraq.tv.data

/**
 * A district (qadha) within a governorate — the unit prayer times are actually
 * calculated for. Coordinates are approximate district-center points; accurate
 * enough for prayer-time calculation, which doesn't need survey-grade precision.
 */
data class District(
    val id: String,
    val displayName: String,
    val latitude: Double,
    val longitude: Double
)

/** One of Iraq's 18 governorates (muhafazat), each containing several districts. */
data class Governorate(
    val id: String,
    val displayName: String,
    val districts: List<District>
)

object IraqRegions {

    val ALL: List<Governorate> = listOf(
        Governorate(
            "baghdad", "Baghdad", listOf(
                District("baghdad_karkh", "Karkh", 33.3106, 44.3600),
                District("baghdad_rusafa", "Rusafa", 33.3406, 44.4009),
                District("baghdad_adhamiyah", "Adhamiyah", 33.3672, 44.4361),
                District("baghdad_kadhimiya", "Kadhimiya", 33.3775, 44.3406),
                District("baghdad_madain", "Mada'in", 33.1667, 44.5833),
                District("baghdad_abu_ghraib", "Abu Ghraib", 33.3050, 44.1889),
                District("baghdad_tarmiyah", "Tarmiyah", 33.6167, 44.2833),
                District("baghdad_mahmudiyah", "Mahmudiyah", 33.0500, 44.3667),
                District("baghdad_taji", "Taji", 33.5667, 44.3333)
            )
        ),
        Governorate(
            "basra", "Basra", listOf(
                District("basra_center", "Basra", 30.5085, 47.7835),
                District("basra_abu_khaseeb", "Abu Al-Khaseeb", 30.4167, 47.8500),
                District("basra_faw", "Al-Faw", 29.9833, 48.4667),
                District("basra_qurna", "Al-Qurna", 31.0167, 47.4333),
                District("basra_zubair", "Al-Zubair", 30.3917, 47.7000),
                District("basra_midaina", "Al-Midaina", 30.7833, 47.6667),
                District("basra_shatt_al_arab", "Shatt Al-Arab", 30.5500, 48.0167)
            )
        ),
        Governorate(
            "nineveh", "Nineveh", listOf(
                District("nineveh_mosul", "Mosul", 36.3489, 43.1189),
                District("nineveh_tel_afar", "Tel Afar", 36.3739, 42.4531),
                District("nineveh_sinjar", "Sinjar", 36.3167, 41.8667),
                District("nineveh_hamdaniya", "Al-Hamdaniya", 36.2833, 43.3833),
                District("nineveh_baaj", "Al-Ba'aj", 36.0500, 42.1167),
                District("nineveh_hatra", "Hatra", 35.5833, 42.7167),
                District("nineveh_shikhan", "Al-Shikhan", 36.6500, 43.2000),
                District("nineveh_tilkaif", "Tilkaif", 36.5333, 43.1167)
            )
        ),
        Governorate(
            "erbil", "Erbil", listOf(
                District("erbil_center", "Erbil", 36.1901, 44.0091),
                District("erbil_soran", "Soran", 36.6528, 44.5417),
                District("erbil_koya", "Koya", 36.0833, 44.6167),
                District("erbil_shaqlawa", "Shaqlawa", 36.4133, 44.3172),
                District("erbil_makhmur", "Makhmur", 35.7500, 43.5833),
                District("erbil_choman", "Choman", 36.6167, 44.9000)
            )
        ),
        Governorate(
            "najaf", "Najaf", listOf(
                District("najaf_center", "Najaf", 31.9958, 44.3288),
                District("najaf_kufa", "Kufa", 32.0333, 44.4033),
                District("najaf_manathira", "Al-Manathira", 32.2167, 44.3833),
                District("najaf_mishkhab", "Al-Mishkhab", 31.7833, 44.3667)
            )
        ),
        Governorate(
            "karbala", "Karbala", listOf(
                District("karbala_center", "Karbala", 32.6160, 44.0249),
                District("karbala_ain_tamr", "Ain Al-Tamr", 32.4333, 43.6667),
                District("karbala_hindiya", "Al-Hindiya", 32.7333, 44.2500)
            )
        ),
        Governorate(
            "kirkuk", "Kirkuk", listOf(
                District("kirkuk_center", "Kirkuk", 35.4681, 44.3922),
                District("kirkuk_dibis", "Dibis", 35.5833, 44.0500),
                District("kirkuk_hawija", "Hawija", 35.3167, 43.4833),
                District("kirkuk_daquq", "Daquq", 35.1500, 44.3833)
            )
        ),
        Governorate(
            "sulaymaniyah", "Sulaymaniyah", listOf(
                District("sulaymaniyah_center", "Sulaymaniyah", 35.5650, 45.4329),
                District("sulaymaniyah_chamchamal", "Chamchamal", 35.5333, 44.8333),
                District("sulaymaniyah_kalar", "Kalar", 34.6167, 45.3167),
                District("sulaymaniyah_dukan", "Dukan", 35.9500, 44.9500),
                District("sulaymaniyah_rania", "Rania", 36.2500, 44.8833),
                District("sulaymaniyah_penjwin", "Penjwin", 35.6167, 45.9500)
            )
        ),
        Governorate(
            "duhok", "Duhok", listOf(
                District("duhok_center", "Duhok", 36.8617, 42.9887),
                District("duhok_zakho", "Zakho", 37.1436, 42.6825),
                District("duhok_amedi", "Amedi", 37.0925, 43.4881),
                District("duhok_semel", "Semel", 36.8422, 42.8256),
                District("duhok_akre", "Akre", 36.7369, 43.8908)
            )
        ),
        Governorate(
            "dhi_qar", "Dhi Qar", listOf(
                District("dhiqar_nasiriyah", "Nasiriyah", 31.0439, 46.2578),
                District("dhiqar_suq_shuyukh", "Suq Al-Shuyukh", 30.9333, 46.4333),
                District("dhiqar_rifai", "Al-Rifai", 31.8000, 46.1333),
                District("dhiqar_chibayish", "Al-Chibayish", 30.9333, 46.9000),
                District("dhiqar_shatra", "Shatra", 31.4167, 46.1833)
            )
        ),
        Governorate(
            "maysan", "Maysan", listOf(
                District("maysan_amarah", "Amarah", 31.8354, 47.1443),
                District("maysan_kahla", "Al-Kahla", 31.6667, 47.2000),
                District("maysan_maimouna", "Al-Maimouna", 31.5667, 47.1500),
                District("maysan_qalat_saleh", "Qal'at Saleh", 31.9333, 47.0000),
                District("maysan_ali_gharbi", "Ali Al-Gharbi", 32.4167, 46.7000)
            )
        ),
        Governorate(
            "qadisiyyah", "Al-Qadisiyyah", listOf(
                District("qadisiyyah_diwaniyah", "Diwaniyah", 31.9890, 44.9282),
                District("qadisiyyah_afak", "Afak", 32.0667, 45.2500),
                District("qadisiyyah_shamiya", "Al-Shamiya", 31.8500, 44.6167),
                District("qadisiyyah_hamza", "Al-Hamza", 31.6167, 44.8333)
            )
        ),
        Governorate(
            "wasit", "Wasit", listOf(
                District("wasit_kut", "Kut", 32.5122, 45.8188),
                District("wasit_suwaira", "Al-Suwaira", 32.9167, 44.9500),
                District("wasit_hai", "Al-Hai", 32.1667, 46.0333),
                District("wasit_numaniya", "Al-Numaniya", 32.6667, 45.2833),
                District("wasit_badra", "Badra", 33.1167, 45.9667)
            )
        ),
        Governorate(
            "babil", "Babil", listOf(
                District("babil_hillah", "Hillah", 32.4839, 44.4342),
                District("babil_musayyib", "Al-Musayyib", 32.7833, 44.2917),
                District("babil_mahawil", "Al-Mahawil", 32.6000, 44.3833),
                District("babil_hashimiya", "Al-Hashimiya", 32.4167, 44.6667)
            )
        ),
        Governorate(
            "anbar", "Al Anbar", listOf(
                District("anbar_ramadi", "Ramadi", 33.4224, 43.3054),
                District("anbar_fallujah", "Fallujah", 33.3489, 43.7867),
                District("anbar_heet", "Heet", 33.6367, 42.8228),
                District("anbar_haditha", "Haditha", 34.1467, 42.3556),
                District("anbar_rutba", "Rutba", 33.0367, 40.2842),
                District("anbar_qaim", "Al-Qaim", 34.3789, 41.1367),
                District("anbar_anah", "Anah", 34.3833, 41.9167)
            )
        ),
        Governorate(
            "saladin", "Saladin", listOf(
                District("saladin_tikrit", "Tikrit", 34.6039, 43.6773),
                District("saladin_samarra", "Samarra", 34.1959, 43.8742),
                District("saladin_baiji", "Baiji", 34.9308, 43.4869),
                District("saladin_balad", "Balad", 34.0167, 44.1500),
                District("saladin_dawr", "Ad-Dawr", 34.4667, 43.9667),
                District("saladin_shirqat", "Al-Shirqat", 35.4667, 43.2667),
                District("saladin_tuz", "Tuz Khurmatu", 34.8833, 44.6333)
            )
        ),
        Governorate(
            "diyala", "Diyala", listOf(
                District("diyala_baqubah", "Baqubah", 33.7500, 44.6417),
                District("diyala_khanaqin", "Khanaqin", 34.3428, 45.3856),
                District("diyala_muqdadiya", "Al-Muqdadiya", 33.9833, 44.9333),
                District("diyala_kifri", "Kifri", 34.6833, 44.9667)
            )
        ),
        Governorate(
            "muthanna", "Muthanna", listOf(
                District("muthanna_samawah", "Samawah", 31.3234, 45.2947),
                District("muthanna_rumaitha", "Al-Rumaitha", 31.5333, 45.1833),
                District("muthanna_khidhir", "Al-Khidhir", 31.7333, 44.9500)
            )
        )
    )

    fun governorateById(id: String): Governorate? = ALL.firstOrNull { it.id == id }

    fun districtById(id: String): District? = ALL.flatMap { it.districts }.firstOrNull { it.id == id }

    fun governorateForDistrict(districtId: String): Governorate? =
        ALL.firstOrNull { gov -> gov.districts.any { it.id == districtId } }

    /** Default selection used the first time the app runs. */
    fun defaultDistrict(): District = ALL.first().districts.first()
}
